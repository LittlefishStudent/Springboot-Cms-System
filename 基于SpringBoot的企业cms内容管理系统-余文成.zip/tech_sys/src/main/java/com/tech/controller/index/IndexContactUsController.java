package com.tech.controller.index;

import com.tech.controller.*;
import com.tech.dao.*;
import com.tech.model.*;
import com.tech.service.*;
import com.tech.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@Controller
@RequestMapping("/commonapi/contact")
public class IndexContactUsController {
    @Autowired
    NormalQuestionMapper NormalQuestionMapper;
    @Autowired
    SysSettingMapper sysSettingMapper;
    @Autowired
    LinkUrlMapper linkUrlMapper;
    /**
            进入搜索列表接口
    **/
    @RequestMapping(value = "")
    public String index(ModelMap modelMap,  HttpServletRequest request) {
        SysSettingExample se = new SysSettingExample();
    	List<SysSetting> sl = sysSettingMapper.selectByExample(se);
    	modelMap.addAttribute("setting", sl.get(0));
        LinkUrlExample le = new LinkUrlExample();
        List<LinkUrl> ll =linkUrlMapper.selectByExample(le);
        modelMap.addAttribute("ll", ll);
        return "index/contact_us";
    }


    
    
}

