package com.tech.controller.index;

import com.tech.controller.LoginModel;
import com.tech.dao.*;
import com.tech.model.*;
import com.tech.service.*;
import com.tech.util.CommonVal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@Controller
@RequestMapping("/commonapi/about")
public class IndexAboutController {
    @Autowired
    AdminInfoMapper adminInfoMapper;
    @Autowired
    SysSettingMapper sysSettingMapper;
    @Autowired
    NewsInfoMapper newsInfoMapper;
    @Autowired
    ProductInfoMapper productInfoMapper;
    @Autowired
    BussinessIntroMapper bussinessIntroMapper;
    @Autowired
    LinkUrlMapper linkUrlMapper;
    @Autowired
    CustomerMsgMapper customerMsgMapper;
    
    
    /**
      管理员角色进入管理首页接口
    */
    @RequestMapping(value = "")
    public String index(ModelMap modelMap, HttpServletRequest request) {
    	
    	SysSettingExample se = new SysSettingExample();
    	List<SysSetting> sl = sysSettingMapper.selectByExample(se);
    	modelMap.addAttribute("setting", sl.get(0));
        LinkUrlExample le = new LinkUrlExample();
        List<LinkUrl> ll =linkUrlMapper.selectByExample(le);
        modelMap.addAttribute("ll", ll);
     return "index/about_us";
    }
}

