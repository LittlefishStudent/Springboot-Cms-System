package com.tech.controller.index;

import com.tech.controller.LoginModel;
import com.tech.dao.*;
import com.tech.model.*;
import com.tech.service.*;
import com.tech.util.CommonVal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Springboot设计理念，完全采用注解形式
 */
@Controller
@RequestMapping("")
public class IndexController {
    @Autowired
    AdminInfoMapper adminInfoMapper;
    @Autowired
    SysSettingMapper sysSettingMapper;
    @Autowired
    NewsInfoMapper newsInfoMapper;
    @Autowired
    ProductInfoMapper productInfoMapper;
    @Autowired
    BussinessIntroMapper bussinessIntroMapper;
    @Autowired
    LinkUrlMapper linkUrlMapper;
    @Autowired
    CustomerMsgMapper customerMsgMapper;
    
    
    /**
      管理员角色进入管理首页接口
    */
    @RequestMapping(value = "")
    public String index(ModelMap modelMap, HttpServletRequest request) {
    	
    	SysSettingExample se = new SysSettingExample();
    	List<SysSetting> sl = sysSettingMapper.selectByExample(se);
    	modelMap.addAttribute("setting", sl.get(0));
    	
    	
        
        
        BussinessIntroExample be2 = new BussinessIntroExample();
     be2.setOrderByClause("id desc"); //默认按照id倒序排序
     be2.setPageRows(4);
     be2.setStartRow(0);
     List< BussinessIntro> bl2 = bussinessIntroMapper.selectByExample(be2);
     modelMap.addAttribute("bl2", bl2);
     
     NewsInfoExample ne = new NewsInfoExample();
     ne.setOrderByClause("id desc"); //默认按照id倒序排序
     ne.setPageRows(4);
     ne.setStartRow(0);
     List< NewsInfo> nl =newsInfoMapper.selectByExample(ne);
     modelMap.addAttribute("nl", nl);
     
     ProductInfoExample pe = new ProductInfoExample();
     pe.setOrderByClause("id desc"); //默认按照id倒序排序
     pe.setPageRows(16);
     pe.setStartRow(0);
     List< ProductInfo> pl =productInfoMapper.selectByExample(pe);
     modelMap.addAttribute("pl", pl);
     
     CustomerMsgExample ce = new CustomerMsgExample();
     List<CustomerMsg> cl = customerMsgMapper.selectByExample(ce);
     modelMap.addAttribute("cl", cl);
     
     LinkUrlExample le = new LinkUrlExample();
     List<LinkUrl> ll =linkUrlMapper.selectByExample(le);
     modelMap.addAttribute("ll", ll);
     return "index/index";
    }
}

