package com.tech.model;

public class ProductInfo {
    private Integer id; //ID
    private String proName; //产品名
    private String proImg; //产品大图
    private String proIntro; //产品详情
    private Integer proTypeId; //产品类型

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getProName() {
        return proName;
    }

    public void setProName(String proName) {
        this.proName = (proName == null) ? null : proName.trim();
    }

    public String getProImg() {
        return proImg;
    }

    public void setProImg(String proImg) {
        this.proImg = (proImg == null) ? null : proImg.trim();
    }

    public String getProIntro() {
        return proIntro;
    }

    public void setProIntro(String proIntro) {
        this.proIntro = (proIntro == null) ? null : proIntro.trim();
    }

    public Integer getProTypeId() {
        return proTypeId;
    }

    public void setProTypeId(Integer proTypeId) {
        this.proTypeId = proTypeId;
    }
}

