package com.tech.model;

public class CustomerMsg {
    private Integer id; //ID
    private String customerImg; //客户logo
    private String customerUrl; //客户链接

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCustomerImg() {
        return customerImg;
    }

    public void setCustomerImg(String customerImg) {
        this.customerImg = (customerImg == null) ? null : customerImg.trim();
    }

    public String getCustomerUrl() {
        return customerUrl;
    }

    public void setCustomerUrl(String customerUrl) {
        this.customerUrl = (customerUrl == null) ? null : customerUrl.trim();
    }
}

