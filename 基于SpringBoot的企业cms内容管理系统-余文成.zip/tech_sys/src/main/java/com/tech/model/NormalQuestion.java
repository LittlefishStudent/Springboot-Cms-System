package com.tech.model;

public class NormalQuestion {
    private Integer id; //ID
    private String questionTitle; //问题标题
    private String questionIntro; //问题描述
    private String createTime; //发布时间

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getQuestionTitle() {
        return questionTitle;
    }

    public void setQuestionTitle(String questionTitle) {
        this.questionTitle = (questionTitle == null) ? null : questionTitle.trim();
    }

    public String getQuestionIntro() {
        return questionIntro;
    }

    public void setQuestionIntro(String questionIntro) {
        this.questionIntro = (questionIntro == null) ? null : questionIntro.trim();
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = (createTime == null) ? null : createTime.trim();
    }
}

