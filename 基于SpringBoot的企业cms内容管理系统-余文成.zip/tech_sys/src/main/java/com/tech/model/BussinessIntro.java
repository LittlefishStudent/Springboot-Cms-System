package com.tech.model;

public class BussinessIntro {
    private Integer id; //ID
    private String title; //标题
    private String subTitle; //副标题
    private String bussinessDetail; //详细介绍

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = (title == null) ? null : title.trim();
    }

    public String getSubTitle() {
        return subTitle;
    }

    public void setSubTitle(String subTitle) {
        this.subTitle = (subTitle == null) ? null : subTitle.trim();
    }

    public String getBussinessDetail() {
        return bussinessDetail;
    }

    public void setBussinessDetail(String bussinessDetail) {
        this.bussinessDetail = (bussinessDetail == null) ? null
                                                         : bussinessDetail.trim();
    }
}

