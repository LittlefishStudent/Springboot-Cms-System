package com.tech.model;

public class SysSetting {
    private Integer id; //ID
    private String wetchatImg; //微信二维码
    private String sqTel; //售前电话
    private String shTel; //售后热线
    private String contactTel; //联系电话
    private String qqVal; //联系QQ
    private String email; //联系邮箱
    private String sysTitle; //系统标题
    private String sysIntro; //系统描述
    private String beianNo; //备案号
    private String companyName; //公司名
    private String companyAddress; //公司地址
    private String companyLat; //经度
    private String companyLng; //纬度

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getWetchatImg() {
        return wetchatImg;
    }

    public void setWetchatImg(String wetchatImg) {
        this.wetchatImg = (wetchatImg == null) ? null : wetchatImg.trim();
    }

    public String getSqTel() {
        return sqTel;
    }

    public void setSqTel(String sqTel) {
        this.sqTel = (sqTel == null) ? null : sqTel.trim();
    }

    public String getShTel() {
        return shTel;
    }

    public void setShTel(String shTel) {
        this.shTel = (shTel == null) ? null : shTel.trim();
    }

    public String getContactTel() {
        return contactTel;
    }

    public void setContactTel(String contactTel) {
        this.contactTel = (contactTel == null) ? null : contactTel.trim();
    }

    public String getQqVal() {
        return qqVal;
    }

    public void setQqVal(String qqVal) {
        this.qqVal = (qqVal == null) ? null : qqVal.trim();
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = (email == null) ? null : email.trim();
    }

    public String getSysTitle() {
        return sysTitle;
    }

    public void setSysTitle(String sysTitle) {
        this.sysTitle = (sysTitle == null) ? null : sysTitle.trim();
    }

    public String getSysIntro() {
        return sysIntro;
    }

    public void setSysIntro(String sysIntro) {
        this.sysIntro = (sysIntro == null) ? null : sysIntro.trim();
    }

    public String getBeianNo() {
        return beianNo;
    }

    public void setBeianNo(String beianNo) {
        this.beianNo = (beianNo == null) ? null : beianNo.trim();
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = (companyName == null) ? null : companyName.trim();
    }

    public String getCompanyAddress() {
        return companyAddress;
    }

    public void setCompanyAddress(String companyAddress) {
        this.companyAddress = (companyAddress == null) ? null
                                                       : companyAddress.trim();
    }

    public String getCompanyLat() {
        return companyLat;
    }

    public void setCompanyLat(String companyLat) {
        this.companyLat = (companyLat == null) ? null : companyLat.trim();
    }

    public String getCompanyLng() {
        return companyLng;
    }

    public void setCompanyLng(String companyLng) {
        this.companyLng = (companyLng == null) ? null : companyLng.trim();
    }
}

