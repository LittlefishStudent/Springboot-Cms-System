package com.tech.model;
import java.util.ArrayList;
import java.util.List;
public class NewsInfoExample {
    protected String orderByClause;
    protected boolean distinct;
    protected int startRow;
    protected int pageRows;
    protected List<Criteria> oredCriteria;
    public NewsInfoExample() {
        oredCriteria = new ArrayList<>();
    }
    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }
    public String getOrderByClause() {
        return orderByClause;
    }
    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }
    public boolean isDistinct() {
        return distinct;
    }
    public void setStartRow(int startRow) {
        this.startRow = startRow;
    }
    public int getStartRow() {
        return startRow;
    }
    public void setPageRows(int pageRows) {
        this.pageRows = pageRows;
    }
    public int getPageRows() {
        return pageRows;
    }
    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }
    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }
    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }
    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }
    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }
    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;
        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<>();
        }
        public boolean isValid() {
            return criteria.size() > 0;
        }
        public List<Criterion> getAllCriteria() {
            return criteria;
        }
        public List<Criterion> getCriteria() {
            return criteria;
        }
        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }
        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }
        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }
    public Criteria andIdIsNull() {
		 addCriterion("id is null");
		return (Criteria) this;
		}
  public Criteria andIdIsNotNull(){
		addCriterion("id is not null");
		return (Criteria) this;
		}
  public Criteria andIdEqualTo(Integer value) {
		  addCriterion("id =", value, "id");
		return (Criteria) this;
		}
   public Criteria andIdNotEqualTo(Integer value) {
		  addCriterion("id <>", value, "id");
		return (Criteria) this;
		}
    public Criteria andIdGreaterThan(Integer value) {
		 addCriterion("id >", value, "id");
		return (Criteria) this;
		}
  public Criteria andIdGreaterThanOrEqualTo(Integer value) {
		  addCriterion("id >=", value, "Id");
		return (Criteria) this;
		}
   public Criteria andIdLessThan(Integer value) {
		  addCriterion("id <", value, "id");
		return (Criteria) this;
		}
    public Criteria andIdLessThanOrEqualTo(Integer value) {
		  addCriterion("id <=", value, "id");
		return (Criteria) this;
		}
    public Criteria andIdIn(List<Integer> values) {
		  addCriterion("id in", values, "id");
		return (Criteria) this;
		}
    public Criteria andIdNotIn(List<Integer> values) {
		  addCriterion("id not in", values, "id");
		return (Criteria) this;
		}
     public Criteria andIdBetween(Integer value1, Integer value2) {
		   addCriterion("id between", value1, value2, "id");
		return (Criteria) this;
		}
     public Criteria andIdNotBetween(Integer value1, Integer value2) {
		   addCriterion("id not between", value1, value2, "id");
		return (Criteria) this;
		}
    public Criteria andIdLike(Integer value) {
		  addCriterion("id like", value, "id");
		return (Criteria) this;
		}
    public Criteria andIdNotLike(Integer value) {
		  addCriterion("id not like", value, "id");
		return (Criteria) this;
		}
 public Criteria andTitleIsNull() {
		 addCriterion("title is null");
		return (Criteria) this;
		}
  public Criteria andTitleIsNotNull(){
		addCriterion("title is not null");
		return (Criteria) this;
		}
  public Criteria andTitleEqualTo(String value) {
		  addCriterion("title =", value, "title");
		return (Criteria) this;
		}
   public Criteria andTitleNotEqualTo(String value) {
		  addCriterion("title <>", value, "title");
		return (Criteria) this;
		}
    public Criteria andTitleGreaterThan(String value) {
		 addCriterion("title >", value, "title");
		return (Criteria) this;
		}
  public Criteria andTitleGreaterThanOrEqualTo(String value) {
		  addCriterion("title >=", value, "Title");
		return (Criteria) this;
		}
   public Criteria andTitleLessThan(String value) {
		  addCriterion("title <", value, "title");
		return (Criteria) this;
		}
    public Criteria andTitleLessThanOrEqualTo(String value) {
		  addCriterion("title <=", value, "title");
		return (Criteria) this;
		}
    public Criteria andTitleIn(List<String> values) {
		  addCriterion("title in", values, "title");
		return (Criteria) this;
		}
    public Criteria andTitleNotIn(List<String> values) {
		  addCriterion("title not in", values, "title");
		return (Criteria) this;
		}
     public Criteria andTitleBetween(String value1, String value2) {
		   addCriterion("title between", value1, value2, "title");
		return (Criteria) this;
		}
     public Criteria andTitleNotBetween(String value1, String value2) {
		   addCriterion("title not between", value1, value2, "title");
		return (Criteria) this;
		}
    public Criteria andTitleLike(String value) {
		  addCriterion("title like", value, "title");
		return (Criteria) this;
		}
    public Criteria andTitleNotLike(String value) {
		  addCriterion("title not like", value, "title");
		return (Criteria) this;
		}
 public Criteria andNewsImgIsNull() {
		 addCriterion("news_img is null");
		return (Criteria) this;
		}
  public Criteria andNewsImgIsNotNull(){
		addCriterion("news_img is not null");
		return (Criteria) this;
		}
  public Criteria andNewsImgEqualTo(String value) {
		  addCriterion("news_img =", value, "newsImg");
		return (Criteria) this;
		}
   public Criteria andNewsImgNotEqualTo(String value) {
		  addCriterion("news_img <>", value, "newsImg");
		return (Criteria) this;
		}
    public Criteria andNewsImgGreaterThan(String value) {
		 addCriterion("news_img >", value, "newsImg");
		return (Criteria) this;
		}
  public Criteria andNewsImgGreaterThanOrEqualTo(String value) {
		  addCriterion("news_img >=", value, "NewsImg");
		return (Criteria) this;
		}
   public Criteria andNewsImgLessThan(String value) {
		  addCriterion("news_img <", value, "newsImg");
		return (Criteria) this;
		}
    public Criteria andNewsImgLessThanOrEqualTo(String value) {
		  addCriterion("news_img <=", value, "newsImg");
		return (Criteria) this;
		}
    public Criteria andNewsImgIn(List<String> values) {
		  addCriterion("news_img in", values, "newsImg");
		return (Criteria) this;
		}
    public Criteria andNewsImgNotIn(List<String> values) {
		  addCriterion("news_img not in", values, "newsImg");
		return (Criteria) this;
		}
     public Criteria andNewsImgBetween(String value1, String value2) {
		   addCriterion("news_img between", value1, value2, "newsImg");
		return (Criteria) this;
		}
     public Criteria andNewsImgNotBetween(String value1, String value2) {
		   addCriterion("news_img not between", value1, value2, "newsImg");
		return (Criteria) this;
		}
    public Criteria andNewsImgLike(String value) {
		  addCriterion("news_img like", value, "newsImg");
		return (Criteria) this;
		}
    public Criteria andNewsImgNotLike(String value) {
		  addCriterion("news_img not like", value, "newsImg");
		return (Criteria) this;
		}
 public Criteria andContentIsNull() {
		 addCriterion("content is null");
		return (Criteria) this;
		}
  public Criteria andContentIsNotNull(){
		addCriterion("content is not null");
		return (Criteria) this;
		}
  public Criteria andContentEqualTo(String value) {
		  addCriterion("content =", value, "content");
		return (Criteria) this;
		}
   public Criteria andContentNotEqualTo(String value) {
		  addCriterion("content <>", value, "content");
		return (Criteria) this;
		}
    public Criteria andContentGreaterThan(String value) {
		 addCriterion("content >", value, "content");
		return (Criteria) this;
		}
  public Criteria andContentGreaterThanOrEqualTo(String value) {
		  addCriterion("content >=", value, "Content");
		return (Criteria) this;
		}
   public Criteria andContentLessThan(String value) {
		  addCriterion("content <", value, "content");
		return (Criteria) this;
		}
    public Criteria andContentLessThanOrEqualTo(String value) {
		  addCriterion("content <=", value, "content");
		return (Criteria) this;
		}
    public Criteria andContentIn(List<String> values) {
		  addCriterion("content in", values, "content");
		return (Criteria) this;
		}
    public Criteria andContentNotIn(List<String> values) {
		  addCriterion("content not in", values, "content");
		return (Criteria) this;
		}
     public Criteria andContentBetween(String value1, String value2) {
		   addCriterion("content between", value1, value2, "content");
		return (Criteria) this;
		}
     public Criteria andContentNotBetween(String value1, String value2) {
		   addCriterion("content not between", value1, value2, "content");
		return (Criteria) this;
		}
    public Criteria andContentLike(String value) {
		  addCriterion("content like", value, "content");
		return (Criteria) this;
		}
    public Criteria andContentNotLike(String value) {
		  addCriterion("content not like", value, "content");
		return (Criteria) this;
		}
 public Criteria andPublishDateIsNull() {
		 addCriterion("publish_date is null");
		return (Criteria) this;
		}
  public Criteria andPublishDateIsNotNull(){
		addCriterion("publish_date is not null");
		return (Criteria) this;
		}
  public Criteria andPublishDateEqualTo(String value) {
		  addCriterion("publish_date =", value, "publishDate");
		return (Criteria) this;
		}
   public Criteria andPublishDateNotEqualTo(String value) {
		  addCriterion("publish_date <>", value, "publishDate");
		return (Criteria) this;
		}
    public Criteria andPublishDateGreaterThan(String value) {
		 addCriterion("publish_date >", value, "publishDate");
		return (Criteria) this;
		}
  public Criteria andPublishDateGreaterThanOrEqualTo(String value) {
		  addCriterion("publish_date >=", value, "PublishDate");
		return (Criteria) this;
		}
   public Criteria andPublishDateLessThan(String value) {
		  addCriterion("publish_date <", value, "publishDate");
		return (Criteria) this;
		}
    public Criteria andPublishDateLessThanOrEqualTo(String value) {
		  addCriterion("publish_date <=", value, "publishDate");
		return (Criteria) this;
		}
    public Criteria andPublishDateIn(List<String> values) {
		  addCriterion("publish_date in", values, "publishDate");
		return (Criteria) this;
		}
    public Criteria andPublishDateNotIn(List<String> values) {
		  addCriterion("publish_date not in", values, "publishDate");
		return (Criteria) this;
		}
     public Criteria andPublishDateBetween(String value1, String value2) {
		   addCriterion("publish_date between", value1, value2, "publishDate");
		return (Criteria) this;
		}
     public Criteria andPublishDateNotBetween(String value1, String value2) {
		   addCriterion("publish_date not between", value1, value2, "publishDate");
		return (Criteria) this;
		}
    public Criteria andPublishDateLike(String value) {
		  addCriterion("publish_date like", value, "publishDate");
		return (Criteria) this;
		}
    public Criteria andPublishDateNotLike(String value) {
		  addCriterion("publish_date not like", value, "publishDate");
		return (Criteria) this;
		}
 public Criteria andPublishNameIsNull() {
		 addCriterion("publish_name is null");
		return (Criteria) this;
		}
  public Criteria andPublishNameIsNotNull(){
		addCriterion("publish_name is not null");
		return (Criteria) this;
		}
  public Criteria andPublishNameEqualTo(String value) {
		  addCriterion("publish_name =", value, "publishName");
		return (Criteria) this;
		}
   public Criteria andPublishNameNotEqualTo(String value) {
		  addCriterion("publish_name <>", value, "publishName");
		return (Criteria) this;
		}
    public Criteria andPublishNameGreaterThan(String value) {
		 addCriterion("publish_name >", value, "publishName");
		return (Criteria) this;
		}
  public Criteria andPublishNameGreaterThanOrEqualTo(String value) {
		  addCriterion("publish_name >=", value, "PublishName");
		return (Criteria) this;
		}
   public Criteria andPublishNameLessThan(String value) {
		  addCriterion("publish_name <", value, "publishName");
		return (Criteria) this;
		}
    public Criteria andPublishNameLessThanOrEqualTo(String value) {
		  addCriterion("publish_name <=", value, "publishName");
		return (Criteria) this;
		}
    public Criteria andPublishNameIn(List<String> values) {
		  addCriterion("publish_name in", values, "publishName");
		return (Criteria) this;
		}
    public Criteria andPublishNameNotIn(List<String> values) {
		  addCriterion("publish_name not in", values, "publishName");
		return (Criteria) this;
		}
     public Criteria andPublishNameBetween(String value1, String value2) {
		   addCriterion("publish_name between", value1, value2, "publishName");
		return (Criteria) this;
		}
     public Criteria andPublishNameNotBetween(String value1, String value2) {
		   addCriterion("publish_name not between", value1, value2, "publishName");
		return (Criteria) this;
		}
    public Criteria andPublishNameLike(String value) {
		  addCriterion("publish_name like", value, "publishName");
		return (Criteria) this;
		}
    public Criteria andPublishNameNotLike(String value) {
		  addCriterion("publish_name not like", value, "publishName");
		return (Criteria) this;
		}
 public Criteria andViewNumIsNull() {
		 addCriterion("view_num is null");
		return (Criteria) this;
		}
  public Criteria andViewNumIsNotNull(){
		addCriterion("view_num is not null");
		return (Criteria) this;
		}
  public Criteria andViewNumEqualTo(Integer value) {
		  addCriterion("view_num =", value, "viewNum");
		return (Criteria) this;
		}
   public Criteria andViewNumNotEqualTo(Integer value) {
		  addCriterion("view_num <>", value, "viewNum");
		return (Criteria) this;
		}
    public Criteria andViewNumGreaterThan(Integer value) {
		 addCriterion("view_num >", value, "viewNum");
		return (Criteria) this;
		}
  public Criteria andViewNumGreaterThanOrEqualTo(Integer value) {
		  addCriterion("view_num >=", value, "ViewNum");
		return (Criteria) this;
		}
   public Criteria andViewNumLessThan(Integer value) {
		  addCriterion("view_num <", value, "viewNum");
		return (Criteria) this;
		}
    public Criteria andViewNumLessThanOrEqualTo(Integer value) {
		  addCriterion("view_num <=", value, "viewNum");
		return (Criteria) this;
		}
    public Criteria andViewNumIn(List<Integer> values) {
		  addCriterion("view_num in", values, "viewNum");
		return (Criteria) this;
		}
    public Criteria andViewNumNotIn(List<Integer> values) {
		  addCriterion("view_num not in", values, "viewNum");
		return (Criteria) this;
		}
     public Criteria andViewNumBetween(Integer value1, Integer value2) {
		   addCriterion("view_num between", value1, value2, "viewNum");
		return (Criteria) this;
		}
     public Criteria andViewNumNotBetween(Integer value1, Integer value2) {
		   addCriterion("view_num not between", value1, value2, "viewNum");
		return (Criteria) this;
		}
    public Criteria andViewNumLike(Integer value) {
		  addCriterion("view_num like", value, "viewNum");
		return (Criteria) this;
		}
    public Criteria andViewNumNotLike(Integer value) {
		  addCriterion("view_num not like", value, "viewNum");
		return (Criteria) this;
		}
 public Criteria andNewsTypeIdIsNull() {
		 addCriterion("news_type_id is null");
		return (Criteria) this;
		}
  public Criteria andNewsTypeIdIsNotNull(){
		addCriterion("news_type_id is not null");
		return (Criteria) this;
		}
  public Criteria andNewsTypeIdEqualTo(Integer value) {
		  addCriterion("news_type_id =", value, "newsTypeId");
		return (Criteria) this;
		}
   public Criteria andNewsTypeIdNotEqualTo(Integer value) {
		  addCriterion("news_type_id <>", value, "newsTypeId");
		return (Criteria) this;
		}
    public Criteria andNewsTypeIdGreaterThan(Integer value) {
		 addCriterion("news_type_id >", value, "newsTypeId");
		return (Criteria) this;
		}
  public Criteria andNewsTypeIdGreaterThanOrEqualTo(Integer value) {
		  addCriterion("news_type_id >=", value, "NewsTypeId");
		return (Criteria) this;
		}
   public Criteria andNewsTypeIdLessThan(Integer value) {
		  addCriterion("news_type_id <", value, "newsTypeId");
		return (Criteria) this;
		}
    public Criteria andNewsTypeIdLessThanOrEqualTo(Integer value) {
		  addCriterion("news_type_id <=", value, "newsTypeId");
		return (Criteria) this;
		}
    public Criteria andNewsTypeIdIn(List<Integer> values) {
		  addCriterion("news_type_id in", values, "newsTypeId");
		return (Criteria) this;
		}
    public Criteria andNewsTypeIdNotIn(List<Integer> values) {
		  addCriterion("news_type_id not in", values, "newsTypeId");
		return (Criteria) this;
		}
     public Criteria andNewsTypeIdBetween(Integer value1, Integer value2) {
		   addCriterion("news_type_id between", value1, value2, "newsTypeId");
		return (Criteria) this;
		}
     public Criteria andNewsTypeIdNotBetween(Integer value1, Integer value2) {
		   addCriterion("news_type_id not between", value1, value2, "newsTypeId");
		return (Criteria) this;
		}
    public Criteria andNewsTypeIdLike(Integer value) {
		  addCriterion("news_type_id like", value, "newsTypeId");
		return (Criteria) this;
		}
    public Criteria andNewsTypeIdNotLike(Integer value) {
		  addCriterion("news_type_id not like", value, "newsTypeId");
		return (Criteria) this;
		}

    }
    public static class Criteria extends GeneratedCriteria {
        protected Criteria() {
            super();
        }
    }
    public static class Criterion {
        private String condition;
        private Object value;
        private Object secondValue;
        private boolean noValue;
        private boolean singleValue;
        private boolean betweenValue;
        private boolean listValue;
        private String typeHandler;
        public String getCondition() {
            return condition;
        }
        public Object getValue() {
            return value;
        }
        public Object getSecondValue() {
            return secondValue;
        }
        public boolean isNoValue() {
            return noValue;
        }
        public boolean isSingleValue() {
            return singleValue;
        }
        public boolean isBetweenValue() {
            return betweenValue;
        }
        public boolean isListValue() {
            return listValue;
        }
        public String getTypeHandler() {
            return typeHandler;
        }
        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }
        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }
        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }
        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }
        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}
