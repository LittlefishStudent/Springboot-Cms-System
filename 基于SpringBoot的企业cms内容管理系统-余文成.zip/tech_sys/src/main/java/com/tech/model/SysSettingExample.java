package com.tech.model;
import java.util.ArrayList;
import java.util.List;
public class SysSettingExample {
    protected String orderByClause;
    protected boolean distinct;
    protected int startRow;
    protected int pageRows;
    protected List<Criteria> oredCriteria;
    public SysSettingExample() {
        oredCriteria = new ArrayList<>();
    }
    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }
    public String getOrderByClause() {
        return orderByClause;
    }
    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }
    public boolean isDistinct() {
        return distinct;
    }
    public void setStartRow(int startRow) {
        this.startRow = startRow;
    }
    public int getStartRow() {
        return startRow;
    }
    public void setPageRows(int pageRows) {
        this.pageRows = pageRows;
    }
    public int getPageRows() {
        return pageRows;
    }
    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }
    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }
    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }
    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }
    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }
    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;
        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<>();
        }
        public boolean isValid() {
            return criteria.size() > 0;
        }
        public List<Criterion> getAllCriteria() {
            return criteria;
        }
        public List<Criterion> getCriteria() {
            return criteria;
        }
        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }
        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }
        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }
    public Criteria andIdIsNull() {
		 addCriterion("id is null");
		return (Criteria) this;
		}
  public Criteria andIdIsNotNull(){
		addCriterion("id is not null");
		return (Criteria) this;
		}
  public Criteria andIdEqualTo(Integer value) {
		  addCriterion("id =", value, "id");
		return (Criteria) this;
		}
   public Criteria andIdNotEqualTo(Integer value) {
		  addCriterion("id <>", value, "id");
		return (Criteria) this;
		}
    public Criteria andIdGreaterThan(Integer value) {
		 addCriterion("id >", value, "id");
		return (Criteria) this;
		}
  public Criteria andIdGreaterThanOrEqualTo(Integer value) {
		  addCriterion("id >=", value, "Id");
		return (Criteria) this;
		}
   public Criteria andIdLessThan(Integer value) {
		  addCriterion("id <", value, "id");
		return (Criteria) this;
		}
    public Criteria andIdLessThanOrEqualTo(Integer value) {
		  addCriterion("id <=", value, "id");
		return (Criteria) this;
		}
    public Criteria andIdIn(List<Integer> values) {
		  addCriterion("id in", values, "id");
		return (Criteria) this;
		}
    public Criteria andIdNotIn(List<Integer> values) {
		  addCriterion("id not in", values, "id");
		return (Criteria) this;
		}
     public Criteria andIdBetween(Integer value1, Integer value2) {
		   addCriterion("id between", value1, value2, "id");
		return (Criteria) this;
		}
     public Criteria andIdNotBetween(Integer value1, Integer value2) {
		   addCriterion("id not between", value1, value2, "id");
		return (Criteria) this;
		}
    public Criteria andIdLike(Integer value) {
		  addCriterion("id like", value, "id");
		return (Criteria) this;
		}
    public Criteria andIdNotLike(Integer value) {
		  addCriterion("id not like", value, "id");
		return (Criteria) this;
		}
 public Criteria andWetchatImgIsNull() {
		 addCriterion("wetchat_img is null");
		return (Criteria) this;
		}
  public Criteria andWetchatImgIsNotNull(){
		addCriterion("wetchat_img is not null");
		return (Criteria) this;
		}
  public Criteria andWetchatImgEqualTo(String value) {
		  addCriterion("wetchat_img =", value, "wetchatImg");
		return (Criteria) this;
		}
   public Criteria andWetchatImgNotEqualTo(String value) {
		  addCriterion("wetchat_img <>", value, "wetchatImg");
		return (Criteria) this;
		}
    public Criteria andWetchatImgGreaterThan(String value) {
		 addCriterion("wetchat_img >", value, "wetchatImg");
		return (Criteria) this;
		}
  public Criteria andWetchatImgGreaterThanOrEqualTo(String value) {
		  addCriterion("wetchat_img >=", value, "WetchatImg");
		return (Criteria) this;
		}
   public Criteria andWetchatImgLessThan(String value) {
		  addCriterion("wetchat_img <", value, "wetchatImg");
		return (Criteria) this;
		}
    public Criteria andWetchatImgLessThanOrEqualTo(String value) {
		  addCriterion("wetchat_img <=", value, "wetchatImg");
		return (Criteria) this;
		}
    public Criteria andWetchatImgIn(List<String> values) {
		  addCriterion("wetchat_img in", values, "wetchatImg");
		return (Criteria) this;
		}
    public Criteria andWetchatImgNotIn(List<String> values) {
		  addCriterion("wetchat_img not in", values, "wetchatImg");
		return (Criteria) this;
		}
     public Criteria andWetchatImgBetween(String value1, String value2) {
		   addCriterion("wetchat_img between", value1, value2, "wetchatImg");
		return (Criteria) this;
		}
     public Criteria andWetchatImgNotBetween(String value1, String value2) {
		   addCriterion("wetchat_img not between", value1, value2, "wetchatImg");
		return (Criteria) this;
		}
    public Criteria andWetchatImgLike(String value) {
		  addCriterion("wetchat_img like", value, "wetchatImg");
		return (Criteria) this;
		}
    public Criteria andWetchatImgNotLike(String value) {
		  addCriterion("wetchat_img not like", value, "wetchatImg");
		return (Criteria) this;
		}
 public Criteria andSqTelIsNull() {
		 addCriterion("sq_tel is null");
		return (Criteria) this;
		}
  public Criteria andSqTelIsNotNull(){
		addCriterion("sq_tel is not null");
		return (Criteria) this;
		}
  public Criteria andSqTelEqualTo(String value) {
		  addCriterion("sq_tel =", value, "sqTel");
		return (Criteria) this;
		}
   public Criteria andSqTelNotEqualTo(String value) {
		  addCriterion("sq_tel <>", value, "sqTel");
		return (Criteria) this;
		}
    public Criteria andSqTelGreaterThan(String value) {
		 addCriterion("sq_tel >", value, "sqTel");
		return (Criteria) this;
		}
  public Criteria andSqTelGreaterThanOrEqualTo(String value) {
		  addCriterion("sq_tel >=", value, "SqTel");
		return (Criteria) this;
		}
   public Criteria andSqTelLessThan(String value) {
		  addCriterion("sq_tel <", value, "sqTel");
		return (Criteria) this;
		}
    public Criteria andSqTelLessThanOrEqualTo(String value) {
		  addCriterion("sq_tel <=", value, "sqTel");
		return (Criteria) this;
		}
    public Criteria andSqTelIn(List<String> values) {
		  addCriterion("sq_tel in", values, "sqTel");
		return (Criteria) this;
		}
    public Criteria andSqTelNotIn(List<String> values) {
		  addCriterion("sq_tel not in", values, "sqTel");
		return (Criteria) this;
		}
     public Criteria andSqTelBetween(String value1, String value2) {
		   addCriterion("sq_tel between", value1, value2, "sqTel");
		return (Criteria) this;
		}
     public Criteria andSqTelNotBetween(String value1, String value2) {
		   addCriterion("sq_tel not between", value1, value2, "sqTel");
		return (Criteria) this;
		}
    public Criteria andSqTelLike(String value) {
		  addCriterion("sq_tel like", value, "sqTel");
		return (Criteria) this;
		}
    public Criteria andSqTelNotLike(String value) {
		  addCriterion("sq_tel not like", value, "sqTel");
		return (Criteria) this;
		}
 public Criteria andShTelIsNull() {
		 addCriterion("sh_tel is null");
		return (Criteria) this;
		}
  public Criteria andShTelIsNotNull(){
		addCriterion("sh_tel is not null");
		return (Criteria) this;
		}
  public Criteria andShTelEqualTo(String value) {
		  addCriterion("sh_tel =", value, "shTel");
		return (Criteria) this;
		}
   public Criteria andShTelNotEqualTo(String value) {
		  addCriterion("sh_tel <>", value, "shTel");
		return (Criteria) this;
		}
    public Criteria andShTelGreaterThan(String value) {
		 addCriterion("sh_tel >", value, "shTel");
		return (Criteria) this;
		}
  public Criteria andShTelGreaterThanOrEqualTo(String value) {
		  addCriterion("sh_tel >=", value, "ShTel");
		return (Criteria) this;
		}
   public Criteria andShTelLessThan(String value) {
		  addCriterion("sh_tel <", value, "shTel");
		return (Criteria) this;
		}
    public Criteria andShTelLessThanOrEqualTo(String value) {
		  addCriterion("sh_tel <=", value, "shTel");
		return (Criteria) this;
		}
    public Criteria andShTelIn(List<String> values) {
		  addCriterion("sh_tel in", values, "shTel");
		return (Criteria) this;
		}
    public Criteria andShTelNotIn(List<String> values) {
		  addCriterion("sh_tel not in", values, "shTel");
		return (Criteria) this;
		}
     public Criteria andShTelBetween(String value1, String value2) {
		   addCriterion("sh_tel between", value1, value2, "shTel");
		return (Criteria) this;
		}
     public Criteria andShTelNotBetween(String value1, String value2) {
		   addCriterion("sh_tel not between", value1, value2, "shTel");
		return (Criteria) this;
		}
    public Criteria andShTelLike(String value) {
		  addCriterion("sh_tel like", value, "shTel");
		return (Criteria) this;
		}
    public Criteria andShTelNotLike(String value) {
		  addCriterion("sh_tel not like", value, "shTel");
		return (Criteria) this;
		}
 public Criteria andContactTelIsNull() {
		 addCriterion("contact_tel is null");
		return (Criteria) this;
		}
  public Criteria andContactTelIsNotNull(){
		addCriterion("contact_tel is not null");
		return (Criteria) this;
		}
  public Criteria andContactTelEqualTo(String value) {
		  addCriterion("contact_tel =", value, "contactTel");
		return (Criteria) this;
		}
   public Criteria andContactTelNotEqualTo(String value) {
		  addCriterion("contact_tel <>", value, "contactTel");
		return (Criteria) this;
		}
    public Criteria andContactTelGreaterThan(String value) {
		 addCriterion("contact_tel >", value, "contactTel");
		return (Criteria) this;
		}
  public Criteria andContactTelGreaterThanOrEqualTo(String value) {
		  addCriterion("contact_tel >=", value, "ContactTel");
		return (Criteria) this;
		}
   public Criteria andContactTelLessThan(String value) {
		  addCriterion("contact_tel <", value, "contactTel");
		return (Criteria) this;
		}
    public Criteria andContactTelLessThanOrEqualTo(String value) {
		  addCriterion("contact_tel <=", value, "contactTel");
		return (Criteria) this;
		}
    public Criteria andContactTelIn(List<String> values) {
		  addCriterion("contact_tel in", values, "contactTel");
		return (Criteria) this;
		}
    public Criteria andContactTelNotIn(List<String> values) {
		  addCriterion("contact_tel not in", values, "contactTel");
		return (Criteria) this;
		}
     public Criteria andContactTelBetween(String value1, String value2) {
		   addCriterion("contact_tel between", value1, value2, "contactTel");
		return (Criteria) this;
		}
     public Criteria andContactTelNotBetween(String value1, String value2) {
		   addCriterion("contact_tel not between", value1, value2, "contactTel");
		return (Criteria) this;
		}
    public Criteria andContactTelLike(String value) {
		  addCriterion("contact_tel like", value, "contactTel");
		return (Criteria) this;
		}
    public Criteria andContactTelNotLike(String value) {
		  addCriterion("contact_tel not like", value, "contactTel");
		return (Criteria) this;
		}
 public Criteria andQqValIsNull() {
		 addCriterion("qq_val is null");
		return (Criteria) this;
		}
  public Criteria andQqValIsNotNull(){
		addCriterion("qq_val is not null");
		return (Criteria) this;
		}
  public Criteria andQqValEqualTo(String value) {
		  addCriterion("qq_val =", value, "qqVal");
		return (Criteria) this;
		}
   public Criteria andQqValNotEqualTo(String value) {
		  addCriterion("qq_val <>", value, "qqVal");
		return (Criteria) this;
		}
    public Criteria andQqValGreaterThan(String value) {
		 addCriterion("qq_val >", value, "qqVal");
		return (Criteria) this;
		}
  public Criteria andQqValGreaterThanOrEqualTo(String value) {
		  addCriterion("qq_val >=", value, "QqVal");
		return (Criteria) this;
		}
   public Criteria andQqValLessThan(String value) {
		  addCriterion("qq_val <", value, "qqVal");
		return (Criteria) this;
		}
    public Criteria andQqValLessThanOrEqualTo(String value) {
		  addCriterion("qq_val <=", value, "qqVal");
		return (Criteria) this;
		}
    public Criteria andQqValIn(List<String> values) {
		  addCriterion("qq_val in", values, "qqVal");
		return (Criteria) this;
		}
    public Criteria andQqValNotIn(List<String> values) {
		  addCriterion("qq_val not in", values, "qqVal");
		return (Criteria) this;
		}
     public Criteria andQqValBetween(String value1, String value2) {
		   addCriterion("qq_val between", value1, value2, "qqVal");
		return (Criteria) this;
		}
     public Criteria andQqValNotBetween(String value1, String value2) {
		   addCriterion("qq_val not between", value1, value2, "qqVal");
		return (Criteria) this;
		}
    public Criteria andQqValLike(String value) {
		  addCriterion("qq_val like", value, "qqVal");
		return (Criteria) this;
		}
    public Criteria andQqValNotLike(String value) {
		  addCriterion("qq_val not like", value, "qqVal");
		return (Criteria) this;
		}
 public Criteria andEmailIsNull() {
		 addCriterion("email is null");
		return (Criteria) this;
		}
  public Criteria andEmailIsNotNull(){
		addCriterion("email is not null");
		return (Criteria) this;
		}
  public Criteria andEmailEqualTo(String value) {
		  addCriterion("email =", value, "email");
		return (Criteria) this;
		}
   public Criteria andEmailNotEqualTo(String value) {
		  addCriterion("email <>", value, "email");
		return (Criteria) this;
		}
    public Criteria andEmailGreaterThan(String value) {
		 addCriterion("email >", value, "email");
		return (Criteria) this;
		}
  public Criteria andEmailGreaterThanOrEqualTo(String value) {
		  addCriterion("email >=", value, "Email");
		return (Criteria) this;
		}
   public Criteria andEmailLessThan(String value) {
		  addCriterion("email <", value, "email");
		return (Criteria) this;
		}
    public Criteria andEmailLessThanOrEqualTo(String value) {
		  addCriterion("email <=", value, "email");
		return (Criteria) this;
		}
    public Criteria andEmailIn(List<String> values) {
		  addCriterion("email in", values, "email");
		return (Criteria) this;
		}
    public Criteria andEmailNotIn(List<String> values) {
		  addCriterion("email not in", values, "email");
		return (Criteria) this;
		}
     public Criteria andEmailBetween(String value1, String value2) {
		   addCriterion("email between", value1, value2, "email");
		return (Criteria) this;
		}
     public Criteria andEmailNotBetween(String value1, String value2) {
		   addCriterion("email not between", value1, value2, "email");
		return (Criteria) this;
		}
    public Criteria andEmailLike(String value) {
		  addCriterion("email like", value, "email");
		return (Criteria) this;
		}
    public Criteria andEmailNotLike(String value) {
		  addCriterion("email not like", value, "email");
		return (Criteria) this;
		}
 public Criteria andSysTitleIsNull() {
		 addCriterion("sys_title is null");
		return (Criteria) this;
		}
  public Criteria andSysTitleIsNotNull(){
		addCriterion("sys_title is not null");
		return (Criteria) this;
		}
  public Criteria andSysTitleEqualTo(String value) {
		  addCriterion("sys_title =", value, "sysTitle");
		return (Criteria) this;
		}
   public Criteria andSysTitleNotEqualTo(String value) {
		  addCriterion("sys_title <>", value, "sysTitle");
		return (Criteria) this;
		}
    public Criteria andSysTitleGreaterThan(String value) {
		 addCriterion("sys_title >", value, "sysTitle");
		return (Criteria) this;
		}
  public Criteria andSysTitleGreaterThanOrEqualTo(String value) {
		  addCriterion("sys_title >=", value, "SysTitle");
		return (Criteria) this;
		}
   public Criteria andSysTitleLessThan(String value) {
		  addCriterion("sys_title <", value, "sysTitle");
		return (Criteria) this;
		}
    public Criteria andSysTitleLessThanOrEqualTo(String value) {
		  addCriterion("sys_title <=", value, "sysTitle");
		return (Criteria) this;
		}
    public Criteria andSysTitleIn(List<String> values) {
		  addCriterion("sys_title in", values, "sysTitle");
		return (Criteria) this;
		}
    public Criteria andSysTitleNotIn(List<String> values) {
		  addCriterion("sys_title not in", values, "sysTitle");
		return (Criteria) this;
		}
     public Criteria andSysTitleBetween(String value1, String value2) {
		   addCriterion("sys_title between", value1, value2, "sysTitle");
		return (Criteria) this;
		}
     public Criteria andSysTitleNotBetween(String value1, String value2) {
		   addCriterion("sys_title not between", value1, value2, "sysTitle");
		return (Criteria) this;
		}
    public Criteria andSysTitleLike(String value) {
		  addCriterion("sys_title like", value, "sysTitle");
		return (Criteria) this;
		}
    public Criteria andSysTitleNotLike(String value) {
		  addCriterion("sys_title not like", value, "sysTitle");
		return (Criteria) this;
		}
 public Criteria andSysIntroIsNull() {
		 addCriterion("sys_intro is null");
		return (Criteria) this;
		}
  public Criteria andSysIntroIsNotNull(){
		addCriterion("sys_intro is not null");
		return (Criteria) this;
		}
  public Criteria andSysIntroEqualTo(String value) {
		  addCriterion("sys_intro =", value, "sysIntro");
		return (Criteria) this;
		}
   public Criteria andSysIntroNotEqualTo(String value) {
		  addCriterion("sys_intro <>", value, "sysIntro");
		return (Criteria) this;
		}
    public Criteria andSysIntroGreaterThan(String value) {
		 addCriterion("sys_intro >", value, "sysIntro");
		return (Criteria) this;
		}
  public Criteria andSysIntroGreaterThanOrEqualTo(String value) {
		  addCriterion("sys_intro >=", value, "SysIntro");
		return (Criteria) this;
		}
   public Criteria andSysIntroLessThan(String value) {
		  addCriterion("sys_intro <", value, "sysIntro");
		return (Criteria) this;
		}
    public Criteria andSysIntroLessThanOrEqualTo(String value) {
		  addCriterion("sys_intro <=", value, "sysIntro");
		return (Criteria) this;
		}
    public Criteria andSysIntroIn(List<String> values) {
		  addCriterion("sys_intro in", values, "sysIntro");
		return (Criteria) this;
		}
    public Criteria andSysIntroNotIn(List<String> values) {
		  addCriterion("sys_intro not in", values, "sysIntro");
		return (Criteria) this;
		}
     public Criteria andSysIntroBetween(String value1, String value2) {
		   addCriterion("sys_intro between", value1, value2, "sysIntro");
		return (Criteria) this;
		}
     public Criteria andSysIntroNotBetween(String value1, String value2) {
		   addCriterion("sys_intro not between", value1, value2, "sysIntro");
		return (Criteria) this;
		}
    public Criteria andSysIntroLike(String value) {
		  addCriterion("sys_intro like", value, "sysIntro");
		return (Criteria) this;
		}
    public Criteria andSysIntroNotLike(String value) {
		  addCriterion("sys_intro not like", value, "sysIntro");
		return (Criteria) this;
		}
 public Criteria andBeianNoIsNull() {
		 addCriterion("beian_no is null");
		return (Criteria) this;
		}
  public Criteria andBeianNoIsNotNull(){
		addCriterion("beian_no is not null");
		return (Criteria) this;
		}
  public Criteria andBeianNoEqualTo(String value) {
		  addCriterion("beian_no =", value, "beianNo");
		return (Criteria) this;
		}
   public Criteria andBeianNoNotEqualTo(String value) {
		  addCriterion("beian_no <>", value, "beianNo");
		return (Criteria) this;
		}
    public Criteria andBeianNoGreaterThan(String value) {
		 addCriterion("beian_no >", value, "beianNo");
		return (Criteria) this;
		}
  public Criteria andBeianNoGreaterThanOrEqualTo(String value) {
		  addCriterion("beian_no >=", value, "BeianNo");
		return (Criteria) this;
		}
   public Criteria andBeianNoLessThan(String value) {
		  addCriterion("beian_no <", value, "beianNo");
		return (Criteria) this;
		}
    public Criteria andBeianNoLessThanOrEqualTo(String value) {
		  addCriterion("beian_no <=", value, "beianNo");
		return (Criteria) this;
		}
    public Criteria andBeianNoIn(List<String> values) {
		  addCriterion("beian_no in", values, "beianNo");
		return (Criteria) this;
		}
    public Criteria andBeianNoNotIn(List<String> values) {
		  addCriterion("beian_no not in", values, "beianNo");
		return (Criteria) this;
		}
     public Criteria andBeianNoBetween(String value1, String value2) {
		   addCriterion("beian_no between", value1, value2, "beianNo");
		return (Criteria) this;
		}
     public Criteria andBeianNoNotBetween(String value1, String value2) {
		   addCriterion("beian_no not between", value1, value2, "beianNo");
		return (Criteria) this;
		}
    public Criteria andBeianNoLike(String value) {
		  addCriterion("beian_no like", value, "beianNo");
		return (Criteria) this;
		}
    public Criteria andBeianNoNotLike(String value) {
		  addCriterion("beian_no not like", value, "beianNo");
		return (Criteria) this;
		}
 public Criteria andCompanyNameIsNull() {
		 addCriterion("company_name is null");
		return (Criteria) this;
		}
  public Criteria andCompanyNameIsNotNull(){
		addCriterion("company_name is not null");
		return (Criteria) this;
		}
  public Criteria andCompanyNameEqualTo(String value) {
		  addCriterion("company_name =", value, "companyName");
		return (Criteria) this;
		}
   public Criteria andCompanyNameNotEqualTo(String value) {
		  addCriterion("company_name <>", value, "companyName");
		return (Criteria) this;
		}
    public Criteria andCompanyNameGreaterThan(String value) {
		 addCriterion("company_name >", value, "companyName");
		return (Criteria) this;
		}
  public Criteria andCompanyNameGreaterThanOrEqualTo(String value) {
		  addCriterion("company_name >=", value, "CompanyName");
		return (Criteria) this;
		}
   public Criteria andCompanyNameLessThan(String value) {
		  addCriterion("company_name <", value, "companyName");
		return (Criteria) this;
		}
    public Criteria andCompanyNameLessThanOrEqualTo(String value) {
		  addCriterion("company_name <=", value, "companyName");
		return (Criteria) this;
		}
    public Criteria andCompanyNameIn(List<String> values) {
		  addCriterion("company_name in", values, "companyName");
		return (Criteria) this;
		}
    public Criteria andCompanyNameNotIn(List<String> values) {
		  addCriterion("company_name not in", values, "companyName");
		return (Criteria) this;
		}
     public Criteria andCompanyNameBetween(String value1, String value2) {
		   addCriterion("company_name between", value1, value2, "companyName");
		return (Criteria) this;
		}
     public Criteria andCompanyNameNotBetween(String value1, String value2) {
		   addCriterion("company_name not between", value1, value2, "companyName");
		return (Criteria) this;
		}
    public Criteria andCompanyNameLike(String value) {
		  addCriterion("company_name like", value, "companyName");
		return (Criteria) this;
		}
    public Criteria andCompanyNameNotLike(String value) {
		  addCriterion("company_name not like", value, "companyName");
		return (Criteria) this;
		}
 public Criteria andCompanyAddressIsNull() {
		 addCriterion("company_address is null");
		return (Criteria) this;
		}
  public Criteria andCompanyAddressIsNotNull(){
		addCriterion("company_address is not null");
		return (Criteria) this;
		}
  public Criteria andCompanyAddressEqualTo(String value) {
		  addCriterion("company_address =", value, "companyAddress");
		return (Criteria) this;
		}
   public Criteria andCompanyAddressNotEqualTo(String value) {
		  addCriterion("company_address <>", value, "companyAddress");
		return (Criteria) this;
		}
    public Criteria andCompanyAddressGreaterThan(String value) {
		 addCriterion("company_address >", value, "companyAddress");
		return (Criteria) this;
		}
  public Criteria andCompanyAddressGreaterThanOrEqualTo(String value) {
		  addCriterion("company_address >=", value, "CompanyAddress");
		return (Criteria) this;
		}
   public Criteria andCompanyAddressLessThan(String value) {
		  addCriterion("company_address <", value, "companyAddress");
		return (Criteria) this;
		}
    public Criteria andCompanyAddressLessThanOrEqualTo(String value) {
		  addCriterion("company_address <=", value, "companyAddress");
		return (Criteria) this;
		}
    public Criteria andCompanyAddressIn(List<String> values) {
		  addCriterion("company_address in", values, "companyAddress");
		return (Criteria) this;
		}
    public Criteria andCompanyAddressNotIn(List<String> values) {
		  addCriterion("company_address not in", values, "companyAddress");
		return (Criteria) this;
		}
     public Criteria andCompanyAddressBetween(String value1, String value2) {
		   addCriterion("company_address between", value1, value2, "companyAddress");
		return (Criteria) this;
		}
     public Criteria andCompanyAddressNotBetween(String value1, String value2) {
		   addCriterion("company_address not between", value1, value2, "companyAddress");
		return (Criteria) this;
		}
    public Criteria andCompanyAddressLike(String value) {
		  addCriterion("company_address like", value, "companyAddress");
		return (Criteria) this;
		}
    public Criteria andCompanyAddressNotLike(String value) {
		  addCriterion("company_address not like", value, "companyAddress");
		return (Criteria) this;
		}
 public Criteria andCompanyLatIsNull() {
		 addCriterion("company_lat is null");
		return (Criteria) this;
		}
  public Criteria andCompanyLatIsNotNull(){
		addCriterion("company_lat is not null");
		return (Criteria) this;
		}
  public Criteria andCompanyLatEqualTo(String value) {
		  addCriterion("company_lat =", value, "companyLat");
		return (Criteria) this;
		}
   public Criteria andCompanyLatNotEqualTo(String value) {
		  addCriterion("company_lat <>", value, "companyLat");
		return (Criteria) this;
		}
    public Criteria andCompanyLatGreaterThan(String value) {
		 addCriterion("company_lat >", value, "companyLat");
		return (Criteria) this;
		}
  public Criteria andCompanyLatGreaterThanOrEqualTo(String value) {
		  addCriterion("company_lat >=", value, "CompanyLat");
		return (Criteria) this;
		}
   public Criteria andCompanyLatLessThan(String value) {
		  addCriterion("company_lat <", value, "companyLat");
		return (Criteria) this;
		}
    public Criteria andCompanyLatLessThanOrEqualTo(String value) {
		  addCriterion("company_lat <=", value, "companyLat");
		return (Criteria) this;
		}
    public Criteria andCompanyLatIn(List<String> values) {
		  addCriterion("company_lat in", values, "companyLat");
		return (Criteria) this;
		}
    public Criteria andCompanyLatNotIn(List<String> values) {
		  addCriterion("company_lat not in", values, "companyLat");
		return (Criteria) this;
		}
     public Criteria andCompanyLatBetween(String value1, String value2) {
		   addCriterion("company_lat between", value1, value2, "companyLat");
		return (Criteria) this;
		}
     public Criteria andCompanyLatNotBetween(String value1, String value2) {
		   addCriterion("company_lat not between", value1, value2, "companyLat");
		return (Criteria) this;
		}
    public Criteria andCompanyLatLike(String value) {
		  addCriterion("company_lat like", value, "companyLat");
		return (Criteria) this;
		}
    public Criteria andCompanyLatNotLike(String value) {
		  addCriterion("company_lat not like", value, "companyLat");
		return (Criteria) this;
		}
 public Criteria andCompanyLngIsNull() {
		 addCriterion("company_lng is null");
		return (Criteria) this;
		}
  public Criteria andCompanyLngIsNotNull(){
		addCriterion("company_lng is not null");
		return (Criteria) this;
		}
  public Criteria andCompanyLngEqualTo(String value) {
		  addCriterion("company_lng =", value, "companyLng");
		return (Criteria) this;
		}
   public Criteria andCompanyLngNotEqualTo(String value) {
		  addCriterion("company_lng <>", value, "companyLng");
		return (Criteria) this;
		}
    public Criteria andCompanyLngGreaterThan(String value) {
		 addCriterion("company_lng >", value, "companyLng");
		return (Criteria) this;
		}
  public Criteria andCompanyLngGreaterThanOrEqualTo(String value) {
		  addCriterion("company_lng >=", value, "CompanyLng");
		return (Criteria) this;
		}
   public Criteria andCompanyLngLessThan(String value) {
		  addCriterion("company_lng <", value, "companyLng");
		return (Criteria) this;
		}
    public Criteria andCompanyLngLessThanOrEqualTo(String value) {
		  addCriterion("company_lng <=", value, "companyLng");
		return (Criteria) this;
		}
    public Criteria andCompanyLngIn(List<String> values) {
		  addCriterion("company_lng in", values, "companyLng");
		return (Criteria) this;
		}
    public Criteria andCompanyLngNotIn(List<String> values) {
		  addCriterion("company_lng not in", values, "companyLng");
		return (Criteria) this;
		}
     public Criteria andCompanyLngBetween(String value1, String value2) {
		   addCriterion("company_lng between", value1, value2, "companyLng");
		return (Criteria) this;
		}
     public Criteria andCompanyLngNotBetween(String value1, String value2) {
		   addCriterion("company_lng not between", value1, value2, "companyLng");
		return (Criteria) this;
		}
    public Criteria andCompanyLngLike(String value) {
		  addCriterion("company_lng like", value, "companyLng");
		return (Criteria) this;
		}
    public Criteria andCompanyLngNotLike(String value) {
		  addCriterion("company_lng not like", value, "companyLng");
		return (Criteria) this;
		}

    }
    public static class Criteria extends GeneratedCriteria {
        protected Criteria() {
            super();
        }
    }
    public static class Criterion {
        private String condition;
        private Object value;
        private Object secondValue;
        private boolean noValue;
        private boolean singleValue;
        private boolean betweenValue;
        private boolean listValue;
        private String typeHandler;
        public String getCondition() {
            return condition;
        }
        public Object getValue() {
            return value;
        }
        public Object getSecondValue() {
            return secondValue;
        }
        public boolean isNoValue() {
            return noValue;
        }
        public boolean isSingleValue() {
            return singleValue;
        }
        public boolean isBetweenValue() {
            return betweenValue;
        }
        public boolean isListValue() {
            return listValue;
        }
        public String getTypeHandler() {
            return typeHandler;
        }
        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }
        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }
        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }
        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }
        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}
