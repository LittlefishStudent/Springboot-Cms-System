package com.tech.service.impl;

import com.tech.controller.LoginModel;

import com.tech.dao.*;

import com.tech.model.*;

import com.tech.service.*;

import com.tech.util.*;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import org.springframework.ui.ModelMap;

import java.io.IOException;
import java.io.InputStream;

import java.text.SimpleDateFormat;

import java.util.*;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@Service
public class ProductInfoServiceImpl implements ProductInfoService {
    SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd");
    SimpleDateFormat sdf3 = new SimpleDateFormat("yyyyMMddHHmmss");
    @Autowired
    ProductInfoMapper productInfoMapper;
    @Autowired
    ProductTypeInfoMapper productTypeInfoMapper;

    /**
      新增
    */
    @Override
    public String add(ProductInfo model, LoginModel login) {
        if ((model.getProName() == null) || model.getProName().equals("")) {
            return "产品名为必填属性";
        }

        if (model.getProTypeId() == null) {
            return "产品类型为必填属性";
        }

        if ((model.getProImg() == null) || model.getProImg().equals("")) {
            return "产品大图为必填属性";
        }

        if (model.getProImg() != null) {
            String[] fileSplit = model.getProImg().split(";");

            if (fileSplit.length > 1) {
                return "产品大图的图片数量不能大于1";
            }
        }

        if ((model.getProIntro() == null) || model.getProIntro().equals("")) {
            return "产品详情为必填属性";
        }

        productInfoMapper.insertSelective(model); //插入数据

        return "";
    }

    /**
      修改
    */
    @Override
    public String update(ProductInfo model, LoginModel login) {
        ProductInfo preModel = productInfoMapper.selectByPrimaryKey(model.getId());

        if ((model.getProName() == null) || model.getProName().equals("")) {
            return "产品名为必填属性";
        }

        if (model.getProTypeId() == null) {
            return "产品类型为必填属性";
        }

        if ((model.getProImg() == null) || model.getProImg().equals("")) {
            return "产品大图为必填属性";
        }

        if (model.getProImg() != null) {
            String[] fileSplit = model.getProImg().split(";");

            if (fileSplit.length > 1) {
                return "产品大图的图片数量不能大于1";
            }
        }

        if ((model.getProIntro() == null) || model.getProIntro().equals("")) {
            return "产品详情为必填属性";
        }

        preModel.setProName(model.getProName());
        preModel.setProTypeId(model.getProTypeId());
        preModel.setProImg(model.getProImg());
        preModel.setProIntro(model.getProIntro());
        productInfoMapper.updateByPrimaryKey(preModel); //更新数据

        return "";
    }

    /**
    *根据参数查询产品列表数据
    */
    @Override
    public Map<String, Object> getDataList(ProductInfo queryModel,
        Integer page, Integer pageSize, LoginModel login) {
        ProductInfoExample se = new ProductInfoExample();
        ProductInfoExample.Criteria sc = se.createCriteria();
        se.setOrderByClause("id desc"); //默认按照id倒序排序

        if (queryModel.getId() != null) {
            sc.andIdEqualTo(queryModel.getId());
        }

        if ((queryModel.getProName() != null) &&
                (queryModel.getProName().equals("") == false)) {
            sc.andProNameLike("%" + queryModel.getProName() + "%"); //模糊查询
        }

        int count = (int) productInfoMapper.countByExample(se);
        int totalPage = 0;

        if ((page != null) && (pageSize != null)) { //分页

            if ((count > 0) && ((count % pageSize) == 0)) {
                totalPage = count / pageSize;
            } else {
                totalPage = (count / pageSize) + 1;
            }

            se.setPageRows(pageSize);
            se.setStartRow((page - 1) * pageSize);
        }

        List<ProductInfo> list = productInfoMapper.selectByExample(se); //执行查询语句
        Map<String, Object> rs = new HashMap<String, Object>();
        List<Map<String, Object>> list2 = new ArrayList<Map<String, Object>>();

        for (ProductInfo model : list) {
            list2.add(getProductInfoModel(model, login));
        }

        rs.put("list", list2); //数据列表
        rs.put("count", count); //数据总数
        rs.put("totalPage", totalPage); //总页数

        return rs;
    }

    /**
      封装产品为前台展示的数据形式
    */
    @Override
    public Map<String, Object> getProductInfoModel(ProductInfo model,
        LoginModel login) {
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("productInfo", model);

        if (model.getProTypeId() != null) {
            ProductTypeInfo productTypeInfo = productTypeInfoMapper.selectByPrimaryKey(model.getProTypeId()); //产品类型为外接字段,需要关联产品类型来解释该字段

            if (productTypeInfo != null) {
                map.put("proTypeIdStr", productTypeInfo.getTypeName());
            }
        }

        return map;
    }

    /**
    * 删除数据
    */
    @Override
    public void delete(Integer id) {
        productInfoMapper.deleteByPrimaryKey(id);
    }
}

