package com.tech.service;

import com.tech.controller.LoginModel;

import com.tech.model.*;

import java.io.InputStream;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public interface SysSettingService {
    /**
      分页查询系统设置数据列表
    */
    public Map<String, Object> getDataList(SysSetting queryModel, Integer page,
        Integer pageSize, LoginModel login);

    /**
      封装系统设置为前台展示的数据形式
    */
    public Map<String, Object> getSysSettingModel(SysSetting model,
        LoginModel login);

    /**
      修改
    */
    public String update(SysSetting model, LoginModel login);
}

