package com.tech.service.impl;

import com.tech.controller.LoginModel;

import com.tech.dao.*;

import com.tech.model.*;

import com.tech.service.*;

import com.tech.util.*;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import org.springframework.ui.ModelMap;

import java.io.IOException;
import java.io.InputStream;

import java.text.SimpleDateFormat;

import java.util.*;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@Service
public class NormalQuestionServiceImpl implements NormalQuestionService {
    SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd");
    SimpleDateFormat sdf3 = new SimpleDateFormat("yyyyMMddHHmmss");
    @Autowired
    NormalQuestionMapper normalQuestionMapper;

    /**
      新增
    */
    @Override
    public String add(NormalQuestion model, LoginModel login) {
        if ((model.getQuestionTitle() == null) ||
                model.getQuestionTitle().equals("")) {
            return "问题标题为必填属性";
        }

        if ((model.getQuestionIntro() == null) ||
                model.getQuestionIntro().equals("")) {
            return "问题描述为必填属性";
        }

        model.setCreateTime(sdf2.format(new Date())); //当前日期格式
        normalQuestionMapper.insertSelective(model); //插入数据

        return "";
    }

    /**
      修改
    */
    @Override
    public String update(NormalQuestion model, LoginModel login) {
        NormalQuestion preModel = normalQuestionMapper.selectByPrimaryKey(model.getId());

        if ((model.getQuestionTitle() == null) ||
                model.getQuestionTitle().equals("")) {
            return "问题标题为必填属性";
        }

        if ((model.getQuestionIntro() == null) ||
                model.getQuestionIntro().equals("")) {
            return "问题描述为必填属性";
        }

        preModel.setQuestionTitle(model.getQuestionTitle());
        preModel.setQuestionIntro(model.getQuestionIntro());
        normalQuestionMapper.updateByPrimaryKey(preModel); //更新数据

        return "";
    }

    /**
    *根据参数查询常见问题列表数据
    */
    @Override
    public Map<String, Object> getDataList(NormalQuestion queryModel,
        Integer page, Integer pageSize, LoginModel login) {
        NormalQuestionExample se = new NormalQuestionExample();
        NormalQuestionExample.Criteria sc = se.createCriteria();
        se.setOrderByClause("id desc"); //默认按照id倒序排序

        if (queryModel.getId() != null) {
            sc.andIdEqualTo(queryModel.getId());
        }

        if ((queryModel.getQuestionTitle() != null) &&
                (queryModel.getQuestionTitle().equals("") == false)) {
            sc.andQuestionTitleLike("%" + queryModel.getQuestionTitle() + "%"); //模糊查询
        }

        int count = (int) normalQuestionMapper.countByExample(se);
        int totalPage = 0;

        if ((page != null) && (pageSize != null)) { //分页

            if ((count > 0) && ((count % pageSize) == 0)) {
                totalPage = count / pageSize;
            } else {
                totalPage = (count / pageSize) + 1;
            }

            se.setPageRows(pageSize);
            se.setStartRow((page - 1) * pageSize);
        }

        List<NormalQuestion> list = normalQuestionMapper.selectByExample(se); //执行查询语句
        Map<String, Object> rs = new HashMap<String, Object>();
        List<Map<String, Object>> list2 = new ArrayList<Map<String, Object>>();

        for (NormalQuestion model : list) {
            list2.add(getNormalQuestionModel(model, login));
        }

        rs.put("list", list2); //数据列表
        rs.put("count", count); //数据总数
        rs.put("totalPage", totalPage); //总页数

        return rs;
    }

    /**
      封装常见问题为前台展示的数据形式
    */
    @Override
    public Map<String, Object> getNormalQuestionModel(NormalQuestion model,
        LoginModel login) {
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("normalQuestion", model);

        return map;
    }

    /**
    * 删除数据
    */
    @Override
    public void delete(Integer id) {
        normalQuestionMapper.deleteByPrimaryKey(id);
    }
}

