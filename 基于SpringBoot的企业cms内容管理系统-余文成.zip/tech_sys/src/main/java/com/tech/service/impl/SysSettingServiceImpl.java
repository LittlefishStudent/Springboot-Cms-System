package com.tech.service.impl;

import com.tech.controller.LoginModel;

import com.tech.dao.*;

import com.tech.model.*;

import com.tech.service.*;

import com.tech.util.*;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import org.springframework.ui.ModelMap;

import java.io.IOException;
import java.io.InputStream;

import java.text.SimpleDateFormat;

import java.util.*;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@Service
public class SysSettingServiceImpl implements SysSettingService {
    SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd");
    SimpleDateFormat sdf3 = new SimpleDateFormat("yyyyMMddHHmmss");
    @Autowired
    SysSettingMapper sysSettingMapper;

    /**
      修改
    */
    @Override
    public String update(SysSetting model, LoginModel login) {
        SysSetting preModel = sysSettingMapper.selectByPrimaryKey(model.getId());

        if ((model.getSysTitle() == null) || model.getSysTitle().equals("")) {
            return "系统标题为必填属性";
        }

        if ((model.getSysIntro() == null) || model.getSysIntro().equals("")) {
            return "系统描述为必填属性";
        }

        if ((model.getCompanyName() == null) ||
                model.getCompanyName().equals("")) {
            return "公司名为必填属性";
        }

        if ((model.getCompanyAddress() == null) ||
                model.getCompanyAddress().equals("")) {
            return "公司地址为必填属性";
        }

        if ((model.getCompanyLat() == null) ||
                model.getCompanyLat().equals("")) {
            return "经度为必填属性";
        }

        if ((model.getCompanyLng() == null) ||
                model.getCompanyLng().equals("")) {
            return "纬度为必填属性";
        }

        if ((model.getWetchatImg() == null) ||
                model.getWetchatImg().equals("")) {
            return "微信二维码为必填属性";
        }

        if (model.getWetchatImg() != null) {
            String[] fileSplit = model.getWetchatImg().split(";");

            if (fileSplit.length > 1) {
                return "微信二维码的图片数量不能大于1";
            }
        }

        if ((model.getSqTel() == null) || model.getSqTel().equals("")) {
            return "售前电话为必填属性";
        }

        if ((model.getShTel() == null) || model.getShTel().equals("")) {
            return "售后热线为必填属性";
        }

        if ((model.getContactTel() == null) ||
                model.getContactTel().equals("")) {
            return "联系电话为必填属性";
        }

        if ((model.getQqVal() == null) || model.getQqVal().equals("")) {
            return "联系QQ为必填属性";
        }

        if ((model.getEmail() == null) || model.getEmail().equals("")) {
            return "联系邮箱为必填属性";
        }

        if ((model.getBeianNo() == null) || model.getBeianNo().equals("")) {
            return "备案号为必填属性";
        }

        preModel.setSysTitle(model.getSysTitle());
        preModel.setSysIntro(model.getSysIntro());
        preModel.setCompanyName(model.getCompanyName());
        preModel.setCompanyAddress(model.getCompanyAddress());
        preModel.setCompanyLat(model.getCompanyLat());
        preModel.setCompanyLng(model.getCompanyLng());
        preModel.setWetchatImg(model.getWetchatImg());
        preModel.setSqTel(model.getSqTel());
        preModel.setShTel(model.getShTel());
        preModel.setContactTel(model.getContactTel());
        preModel.setQqVal(model.getQqVal());
        preModel.setEmail(model.getEmail());
        preModel.setBeianNo(model.getBeianNo());
        sysSettingMapper.updateByPrimaryKey(preModel); //更新数据

        return "";
    }

    /**
    *根据参数查询系统设置列表数据
    */
    @Override
    public Map<String, Object> getDataList(SysSetting queryModel, Integer page,
        Integer pageSize, LoginModel login) {
        SysSettingExample se = new SysSettingExample();
        SysSettingExample.Criteria sc = se.createCriteria();
        se.setOrderByClause("id desc"); //默认按照id倒序排序

        if (queryModel.getId() != null) {
            sc.andIdEqualTo(queryModel.getId());
        }

        int count = (int) sysSettingMapper.countByExample(se);
        int totalPage = 0;

        if ((page != null) && (pageSize != null)) { //分页

            if ((count > 0) && ((count % pageSize) == 0)) {
                totalPage = count / pageSize;
            } else {
                totalPage = (count / pageSize) + 1;
            }

            se.setPageRows(pageSize);
            se.setStartRow((page - 1) * pageSize);
        }

        List<SysSetting> list = sysSettingMapper.selectByExample(se); //执行查询语句
        Map<String, Object> rs = new HashMap<String, Object>();
        List<Map<String, Object>> list2 = new ArrayList<Map<String, Object>>();

        for (SysSetting model : list) {
            list2.add(getSysSettingModel(model, login));
        }

        rs.put("list", list2); //数据列表
        rs.put("count", count); //数据总数
        rs.put("totalPage", totalPage); //总页数

        return rs;
    }

    /**
      封装系统设置为前台展示的数据形式
    */
    @Override
    public Map<String, Object> getSysSettingModel(SysSetting model,
        LoginModel login) {
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("sysSetting", model);

        return map;
    }
}

