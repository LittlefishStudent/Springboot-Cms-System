package com.tech.service.impl;

import com.tech.controller.LoginModel;

import com.tech.dao.*;

import com.tech.model.*;

import com.tech.service.*;

import com.tech.util.*;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import org.springframework.ui.ModelMap;

import java.io.IOException;
import java.io.InputStream;

import java.text.SimpleDateFormat;

import java.util.*;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@Service
public class CustomerMsgServiceImpl implements CustomerMsgService {
    SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd");
    SimpleDateFormat sdf3 = new SimpleDateFormat("yyyyMMddHHmmss");
    @Autowired
    CustomerMsgMapper customerMsgMapper;

    /**
      新增
    */
    @Override
    public String add(CustomerMsg model, LoginModel login) {
        if ((model.getCustomerImg() == null) ||
                model.getCustomerImg().equals("")) {
            return "客户logo为必填属性";
        }

        if (model.getCustomerImg() != null) {
            String[] fileSplit = model.getCustomerImg().split(";");

            if (fileSplit.length > 1) {
                return "客户logo的图片数量不能大于1";
            }
        }

        if ((model.getCustomerUrl() == null) ||
                model.getCustomerUrl().equals("")) {
            return "客户链接为必填属性";
        }

        customerMsgMapper.insertSelective(model); //插入数据

        return "";
    }

    /**
      修改
    */
    @Override
    public String update(CustomerMsg model, LoginModel login) {
        CustomerMsg preModel = customerMsgMapper.selectByPrimaryKey(model.getId());

        if ((model.getCustomerImg() == null) ||
                model.getCustomerImg().equals("")) {
            return "客户logo为必填属性";
        }

        if (model.getCustomerImg() != null) {
            String[] fileSplit = model.getCustomerImg().split(";");

            if (fileSplit.length > 1) {
                return "客户logo的图片数量不能大于1";
            }
        }

        if ((model.getCustomerUrl() == null) ||
                model.getCustomerUrl().equals("")) {
            return "客户链接为必填属性";
        }

        preModel.setCustomerImg(model.getCustomerImg());
        preModel.setCustomerUrl(model.getCustomerUrl());
        customerMsgMapper.updateByPrimaryKey(preModel); //更新数据

        return "";
    }

    /**
    *根据参数查询服务客户列表数据
    */
    @Override
    public Map<String, Object> getDataList(CustomerMsg queryModel,
        Integer page, Integer pageSize, LoginModel login) {
        CustomerMsgExample se = new CustomerMsgExample();
        CustomerMsgExample.Criteria sc = se.createCriteria();
        se.setOrderByClause("id desc"); //默认按照id倒序排序

        if (queryModel.getId() != null) {
            sc.andIdEqualTo(queryModel.getId());
        }

        int count = (int) customerMsgMapper.countByExample(se);
        int totalPage = 0;

        if ((page != null) && (pageSize != null)) { //分页

            if ((count > 0) && ((count % pageSize) == 0)) {
                totalPage = count / pageSize;
            } else {
                totalPage = (count / pageSize) + 1;
            }

            se.setPageRows(pageSize);
            se.setStartRow((page - 1) * pageSize);
        }

        List<CustomerMsg> list = customerMsgMapper.selectByExample(se); //执行查询语句
        Map<String, Object> rs = new HashMap<String, Object>();
        List<Map<String, Object>> list2 = new ArrayList<Map<String, Object>>();

        for (CustomerMsg model : list) {
            list2.add(getCustomerMsgModel(model, login));
        }

        rs.put("list", list2); //数据列表
        rs.put("count", count); //数据总数
        rs.put("totalPage", totalPage); //总页数

        return rs;
    }

    /**
      封装服务客户为前台展示的数据形式
    */
    @Override
    public Map<String, Object> getCustomerMsgModel(CustomerMsg model,
        LoginModel login) {
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("customerMsg", model);

        return map;
    }

    /**
    * 删除数据
    */
    @Override
    public void delete(Integer id) {
        customerMsgMapper.deleteByPrimaryKey(id);
    }
}

