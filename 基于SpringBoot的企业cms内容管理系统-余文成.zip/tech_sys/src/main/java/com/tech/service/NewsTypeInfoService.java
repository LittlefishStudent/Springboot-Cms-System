package com.tech.service;

import com.tech.controller.LoginModel;

import com.tech.model.*;

import java.io.InputStream;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public interface NewsTypeInfoService {
    /**
      分页查询新闻类型数据列表
    */
    public Map<String, Object> getDataList(NewsTypeInfo queryModel,
        Integer page, Integer pageSize, LoginModel login);

    /**
      封装新闻类型为前台展示的数据形式
    */
    public Map<String, Object> getNewsTypeInfoModel(NewsTypeInfo model,
        LoginModel login);

    /**
    * 删除数据
    */
    public void delete(Integer id);

    /**
      新增
    */
    public String add(NewsTypeInfo model, LoginModel login);

    /**
      修改
    */
    public String update(NewsTypeInfo model, LoginModel login);
}

