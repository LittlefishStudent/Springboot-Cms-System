package com.tech.service;

import com.tech.controller.LoginModel;

import com.tech.model.*;

import java.io.InputStream;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public interface NormalQuestionService {
    /**
      分页查询常见问题数据列表
    */
    public Map<String, Object> getDataList(NormalQuestion queryModel,
        Integer page, Integer pageSize, LoginModel login);

    /**
      封装常见问题为前台展示的数据形式
    */
    public Map<String, Object> getNormalQuestionModel(NormalQuestion model,
        LoginModel login);

    /**
    * 删除数据
    */
    public void delete(Integer id);

    /**
      新增
    */
    public String add(NormalQuestion model, LoginModel login);

    /**
      修改
    */
    public String update(NormalQuestion model, LoginModel login);
}

