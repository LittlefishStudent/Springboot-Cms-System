package com.tech.service;

import com.tech.controller.LoginModel;

import com.tech.model.*;

import java.io.InputStream;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public interface CustomerMsgService {
    /**
      分页查询服务客户数据列表
    */
    public Map<String, Object> getDataList(CustomerMsg queryModel,
        Integer page, Integer pageSize, LoginModel login);

    /**
      封装服务客户为前台展示的数据形式
    */
    public Map<String, Object> getCustomerMsgModel(CustomerMsg model,
        LoginModel login);

    /**
    * 删除数据
    */
    public void delete(Integer id);

    /**
      新增
    */
    public String add(CustomerMsg model, LoginModel login);

    /**
      修改
    */
    public String update(CustomerMsg model, LoginModel login);
}

