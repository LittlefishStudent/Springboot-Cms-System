package com.tech.dao;

import com.tech.model.ProductTypeInfo;
import com.tech.model.ProductTypeInfoExample;

import org.apache.ibatis.annotations.Param;

import java.util.List;


public interface ProductTypeInfoMapper {
    long countByExample(ProductTypeInfoExample example);

    int deleteByExample(ProductTypeInfoExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(ProductTypeInfo record);

    int insertSelective(ProductTypeInfo record);

    List<ProductTypeInfo> selectByExample(ProductTypeInfoExample example);

    ProductTypeInfo selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record")
    ProductTypeInfo record, @Param("example")
    ProductTypeInfoExample example);

    int updateByExample(@Param("record")
    ProductTypeInfo record, @Param("example")
    ProductTypeInfoExample example);

    int updateByPrimaryKeySelective(ProductTypeInfo record);

    int updateByPrimaryKey(ProductTypeInfo record);
}

