package com.tech.dao;

import com.tech.model.CustomerMsg;
import com.tech.model.CustomerMsgExample;

import org.apache.ibatis.annotations.Param;

import java.util.List;


public interface CustomerMsgMapper {
    long countByExample(CustomerMsgExample example);

    int deleteByExample(CustomerMsgExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(CustomerMsg record);

    int insertSelective(CustomerMsg record);

    List<CustomerMsg> selectByExample(CustomerMsgExample example);

    CustomerMsg selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record")
    CustomerMsg record, @Param("example")
    CustomerMsgExample example);

    int updateByExample(@Param("record")
    CustomerMsg record, @Param("example")
    CustomerMsgExample example);

    int updateByPrimaryKeySelective(CustomerMsg record);

    int updateByPrimaryKey(CustomerMsg record);
}

