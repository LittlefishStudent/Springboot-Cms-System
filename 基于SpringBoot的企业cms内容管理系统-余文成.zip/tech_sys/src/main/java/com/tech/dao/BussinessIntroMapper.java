package com.tech.dao;

import com.tech.model.BussinessIntro;
import com.tech.model.BussinessIntroExample;

import org.apache.ibatis.annotations.Param;

import java.util.List;


public interface BussinessIntroMapper {
    long countByExample(BussinessIntroExample example);

    int deleteByExample(BussinessIntroExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(BussinessIntro record);

    int insertSelective(BussinessIntro record);

    List<BussinessIntro> selectByExample(BussinessIntroExample example);

    BussinessIntro selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record")
    BussinessIntro record, @Param("example")
    BussinessIntroExample example);

    int updateByExample(@Param("record")
    BussinessIntro record, @Param("example")
    BussinessIntroExample example);

    int updateByPrimaryKeySelective(BussinessIntro record);

    int updateByPrimaryKey(BussinessIntro record);
}

