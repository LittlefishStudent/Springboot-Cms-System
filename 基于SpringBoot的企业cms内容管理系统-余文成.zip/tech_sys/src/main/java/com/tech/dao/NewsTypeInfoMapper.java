package com.tech.dao;

import com.tech.model.NewsTypeInfo;
import com.tech.model.NewsTypeInfoExample;

import org.apache.ibatis.annotations.Param;

import java.util.List;


public interface NewsTypeInfoMapper {
    long countByExample(NewsTypeInfoExample example);

    int deleteByExample(NewsTypeInfoExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(NewsTypeInfo record);

    int insertSelective(NewsTypeInfo record);

    List<NewsTypeInfo> selectByExample(NewsTypeInfoExample example);

    NewsTypeInfo selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record")
    NewsTypeInfo record, @Param("example")
    NewsTypeInfoExample example);

    int updateByExample(@Param("record")
    NewsTypeInfo record, @Param("example")
    NewsTypeInfoExample example);

    int updateByPrimaryKeySelective(NewsTypeInfo record);

    int updateByPrimaryKey(NewsTypeInfo record);
}

