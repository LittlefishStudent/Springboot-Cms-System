package com.tech.dao;

import com.tech.model.NormalQuestion;
import com.tech.model.NormalQuestionExample;

import org.apache.ibatis.annotations.Param;

import java.util.List;


public interface NormalQuestionMapper {
    long countByExample(NormalQuestionExample example);

    int deleteByExample(NormalQuestionExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(NormalQuestion record);

    int insertSelective(NormalQuestion record);

    List<NormalQuestion> selectByExample(NormalQuestionExample example);

    NormalQuestion selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record")
    NormalQuestion record, @Param("example")
    NormalQuestionExample example);

    int updateByExample(@Param("record")
    NormalQuestion record, @Param("example")
    NormalQuestionExample example);

    int updateByPrimaryKeySelective(NormalQuestion record);

    int updateByPrimaryKey(NormalQuestion record);
}

