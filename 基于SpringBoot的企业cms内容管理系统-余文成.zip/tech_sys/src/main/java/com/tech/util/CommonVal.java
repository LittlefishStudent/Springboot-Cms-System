package com.tech.util;
public class CommonVal {
	public static String code="206021";//图片存储session
	public static String sessionName="031390";//登录session
	public static Integer pageSize=10;
	
	public static String imgRealPath="";//图片存储真实路径，当为空时使用默认路径;
public static String hostPort = "localhost:8080";//使用ip+端口

}
