CREATE DATABASE IF NOT EXISTS `tech_sys` default charset utf8 COLLATE utf8_general_ci;

USE `tech_sys`;
drop TABLE if EXISTS `admin_info`;
CREATE TABLE IF NOT EXISTS `admin_info` (
 `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
 `login_name` varchar(255) DEFAULT NULL COMMENT '登录名',
 `password` varchar(255) DEFAULT NULL COMMENT '密码',
  PRIMARY KEY (`id`)
 ) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='管理员';


drop TABLE if EXISTS `sys_setting`;
CREATE TABLE IF NOT EXISTS `sys_setting` (
 `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
 `sys_title` varchar(255) DEFAULT NULL COMMENT '系统标题',
 `sys_intro` varchar(1000) DEFAULT NULL COMMENT '系统描述',
 `company_name` varchar(255) DEFAULT NULL COMMENT '公司名',
 `company_address` varchar(255) DEFAULT NULL COMMENT '公司地址',
 `company_lat` varchar(255) DEFAULT NULL COMMENT '经度',
 `company_lng` varchar(255) DEFAULT NULL COMMENT '纬度',
 `wetchat_img` varchar(200) DEFAULT NULL COMMENT '微信二维码',
 `sq_tel` varchar(255) DEFAULT NULL COMMENT '售前电话',
 `sh_tel` varchar(255) DEFAULT NULL COMMENT '售后热线',
 `contact_tel` varchar(255) DEFAULT NULL COMMENT '联系电话',
 `qq_val` varchar(255) DEFAULT NULL COMMENT '联系QQ',
 `email` varchar(255) DEFAULT NULL COMMENT '联系邮箱',
 `beian_no` varchar(255) DEFAULT NULL COMMENT '备案号',
  PRIMARY KEY (`id`)
 ) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='系统设置';


drop TABLE if EXISTS `news_type_info`;
CREATE TABLE IF NOT EXISTS `news_type_info` (
 `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
 `type_name` varchar(255) DEFAULT NULL COMMENT '类型名',
  PRIMARY KEY (`id`)
 ) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='新闻类型';


drop TABLE if EXISTS `news_info`;
CREATE TABLE IF NOT EXISTS `news_info` (
 `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
 `title` varchar(255) DEFAULT NULL COMMENT '标题',
 `news_type_id` int(11) DEFAULT NULL COMMENT '新闻类型',
 `news_img` varchar(200) DEFAULT NULL COMMENT '新闻大图',
 `content` text  COLLATE utf8_bin DEFAULT NULL COMMENT '内容',
 `publish_name` varchar(255) DEFAULT NULL COMMENT '发布人',
 `publish_date` varchar(30) DEFAULT NULL COMMENT '发布日期',
 `view_num` int(11) DEFAULT NULL COMMENT '查阅数量',
  PRIMARY KEY (`id`)
 ) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='新闻';


drop TABLE if EXISTS `product_type_info`;
CREATE TABLE IF NOT EXISTS `product_type_info` (
 `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
 `type_name` varchar(255) DEFAULT NULL COMMENT '类型名',
  PRIMARY KEY (`id`)
 ) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='产品类型';


drop TABLE if EXISTS `product_info`;
CREATE TABLE IF NOT EXISTS `product_info` (
 `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
 `pro_name` varchar(255) DEFAULT NULL COMMENT '产品名',
 `pro_type_id` int(11) DEFAULT NULL COMMENT '产品类型',
 `pro_img` varchar(200) DEFAULT NULL COMMENT '产品大图',
 `pro_intro` varchar(1000) DEFAULT NULL COMMENT '产品详情',
  PRIMARY KEY (`id`)
 ) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='产品';


drop TABLE if EXISTS `normal_question`;
CREATE TABLE IF NOT EXISTS `normal_question` (
 `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
 `question_title` varchar(255) DEFAULT NULL COMMENT '问题标题',
 `question_intro` varchar(1000) DEFAULT NULL COMMENT '问题描述',
 `create_time` varchar(30) DEFAULT NULL COMMENT '发布时间',
  PRIMARY KEY (`id`)
 ) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='常见问题';


drop TABLE if EXISTS `customer_msg`;
CREATE TABLE IF NOT EXISTS `customer_msg` (
 `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
 `customer_img` varchar(200) DEFAULT NULL COMMENT '客户logo',
 `customer_url` varchar(255) DEFAULT NULL COMMENT '客户链接',
  PRIMARY KEY (`id`)
 ) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='服务客户';


drop TABLE if EXISTS `link_url`;
CREATE TABLE IF NOT EXISTS `link_url` (
 `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
 `link_name` varchar(255) DEFAULT NULL COMMENT '链接名',
 `link_url` varchar(255) DEFAULT NULL COMMENT '链接',
  PRIMARY KEY (`id`)
 ) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='友情链接';


drop TABLE if EXISTS `bussiness_intro`;
CREATE TABLE IF NOT EXISTS `bussiness_intro` (
 `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
 `title` varchar(255) DEFAULT NULL COMMENT '标题',
 `sub_title` varchar(255) DEFAULT NULL COMMENT '副标题',
 `bussiness_detail` varchar(1000) DEFAULT NULL COMMENT '详细介绍',
  PRIMARY KEY (`id`)
 ) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='首页业务介绍';



INSERT INTO `tech_sys`.`admin_info` (`id`,`login_name`,`password`)  VALUES('1','admin','123');
INSERT INTO `tech_sys`.`admin_info` (`id`,`login_name`,`password`)  VALUES('2','admin1','123');
INSERT INTO `tech_sys`.`admin_info` (`id`,`login_name`,`password`)  VALUES('3','admin2','123');
INSERT INTO `tech_sys`.`admin_info` (`id`,`login_name`,`password`)  VALUES('4','admin3','123');
INSERT INTO `tech_sys`.`admin_info` (`id`,`login_name`,`password`)  VALUES('5','admin4','123');
INSERT INTO `tech_sys`.`sys_setting` (`id`,`sys_title`,`sys_intro`,`company_name`,`company_address`,`company_lat`,`company_lng`,`wetchat_img`,`sq_tel`,`sh_tel`,`contact_tel`,`qq_val`,`email`,`beian_no`)  VALUES('1','系统标题0','系统描述0','公司名0','公司地址0','经度0','纬度0','http://111.229.176.248/example_img/example9.jpg','售前电话0','售后热线0','联系电话0','联系QQ0','联系邮箱0','备案号0');
INSERT INTO `tech_sys`.`news_type_info` (`id`,`type_name`)  VALUES('1','类型名0');
INSERT INTO `tech_sys`.`news_type_info` (`id`,`type_name`)  VALUES('2','类型名1');
INSERT INTO `tech_sys`.`news_type_info` (`id`,`type_name`)  VALUES('3','类型名2');
INSERT INTO `tech_sys`.`news_type_info` (`id`,`type_name`)  VALUES('4','类型名3');
INSERT INTO `tech_sys`.`news_type_info` (`id`,`type_name`)  VALUES('5','类型名4');
INSERT INTO `tech_sys`.`news_info` (`id`,`title`,`news_type_id`,`news_img`,`content`,`publish_name`,`publish_date`,`view_num`)  VALUES('1','标题0','4','http://111.229.176.248/example_img/example6.jpg','测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试试测试测试测试测试测试测试测试测试测试测试','发布人0','2021-03-10','0');
INSERT INTO `tech_sys`.`news_info` (`id`,`title`,`news_type_id`,`news_img`,`content`,`publish_name`,`publish_date`,`view_num`)  VALUES('2','标题1','3','http://111.229.176.248/example_img/example10.jpg','测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试试测试测试测试测试测试测试测试测试测试测试','发布人1','2021-03-14','0');
INSERT INTO `tech_sys`.`news_info` (`id`,`title`,`news_type_id`,`news_img`,`content`,`publish_name`,`publish_date`,`view_num`)  VALUES('3','标题2','2','http://111.229.176.248/example_img/example3.jpg','测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试试测试测试测试测试测试测试测试测试测试测试','发布人2','2021-03-19','0');
INSERT INTO `tech_sys`.`news_info` (`id`,`title`,`news_type_id`,`news_img`,`content`,`publish_name`,`publish_date`,`view_num`)  VALUES('4','标题3','1','http://111.229.176.248/example_img/example6.jpg','测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试试测试测试测试测试测试测试测试测试测试测试','发布人3','2021-03-24','0');
INSERT INTO `tech_sys`.`news_info` (`id`,`title`,`news_type_id`,`news_img`,`content`,`publish_name`,`publish_date`,`view_num`)  VALUES('5','标题4','3','http://111.229.176.248/example_img/example3.jpg','测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试试测试测试测试测试测试测试测试测试测试测试','发布人4','2021-03-05','0');
INSERT INTO `tech_sys`.`product_type_info` (`id`,`type_name`)  VALUES('1','类型名0');
INSERT INTO `tech_sys`.`product_type_info` (`id`,`type_name`)  VALUES('2','类型名1');
INSERT INTO `tech_sys`.`product_type_info` (`id`,`type_name`)  VALUES('3','类型名2');
INSERT INTO `tech_sys`.`product_type_info` (`id`,`type_name`)  VALUES('4','类型名3');
INSERT INTO `tech_sys`.`product_type_info` (`id`,`type_name`)  VALUES('5','类型名4');
INSERT INTO `tech_sys`.`product_info` (`id`,`pro_name`,`pro_type_id`,`pro_img`,`pro_intro`)  VALUES('1','产品名0','5','http://111.229.176.248/example_img/example9.jpg','产品详情0');
INSERT INTO `tech_sys`.`product_info` (`id`,`pro_name`,`pro_type_id`,`pro_img`,`pro_intro`)  VALUES('2','产品名1','5','http://111.229.176.248/example_img/example8.jpg','产品详情1');
INSERT INTO `tech_sys`.`product_info` (`id`,`pro_name`,`pro_type_id`,`pro_img`,`pro_intro`)  VALUES('3','产品名2','3','http://111.229.176.248/example_img/example9.jpg','产品详情2');
INSERT INTO `tech_sys`.`product_info` (`id`,`pro_name`,`pro_type_id`,`pro_img`,`pro_intro`)  VALUES('4','产品名3','2','http://111.229.176.248/example_img/example9.jpg','产品详情3');
INSERT INTO `tech_sys`.`product_info` (`id`,`pro_name`,`pro_type_id`,`pro_img`,`pro_intro`)  VALUES('5','产品名4','1','http://111.229.176.248/example_img/example4.jpg','产品详情4');
INSERT INTO `tech_sys`.`normal_question` (`id`,`question_title`,`question_intro`,`create_time`)  VALUES('1','问题标题0','问题描述0','2021-03-01');
INSERT INTO `tech_sys`.`normal_question` (`id`,`question_title`,`question_intro`,`create_time`)  VALUES('2','问题标题1','问题描述1','2021-03-11');
INSERT INTO `tech_sys`.`normal_question` (`id`,`question_title`,`question_intro`,`create_time`)  VALUES('3','问题标题2','问题描述2','2021-03-22');
INSERT INTO `tech_sys`.`normal_question` (`id`,`question_title`,`question_intro`,`create_time`)  VALUES('4','问题标题3','问题描述3','2021-03-27');
INSERT INTO `tech_sys`.`normal_question` (`id`,`question_title`,`question_intro`,`create_time`)  VALUES('5','问题标题4','问题描述4','2021-03-21');
INSERT INTO `tech_sys`.`customer_msg` (`id`,`customer_img`,`customer_url`)  VALUES('1','http://111.229.176.248/example_img/example5.jpg','客户链接0');
INSERT INTO `tech_sys`.`customer_msg` (`id`,`customer_img`,`customer_url`)  VALUES('2','http://111.229.176.248/example_img/example1.jpg','客户链接1');
INSERT INTO `tech_sys`.`customer_msg` (`id`,`customer_img`,`customer_url`)  VALUES('3','http://111.229.176.248/example_img/example9.jpg','客户链接2');
INSERT INTO `tech_sys`.`customer_msg` (`id`,`customer_img`,`customer_url`)  VALUES('4','http://111.229.176.248/example_img/example9.jpg','客户链接3');
INSERT INTO `tech_sys`.`customer_msg` (`id`,`customer_img`,`customer_url`)  VALUES('5','http://111.229.176.248/example_img/example3.jpg','客户链接4');
INSERT INTO `tech_sys`.`link_url` (`id`,`link_name`,`link_url`)  VALUES('1','链接名0','链接0');
INSERT INTO `tech_sys`.`link_url` (`id`,`link_name`,`link_url`)  VALUES('2','链接名1','链接1');
INSERT INTO `tech_sys`.`link_url` (`id`,`link_name`,`link_url`)  VALUES('3','链接名2','链接2');
INSERT INTO `tech_sys`.`link_url` (`id`,`link_name`,`link_url`)  VALUES('4','链接名3','链接3');
INSERT INTO `tech_sys`.`link_url` (`id`,`link_name`,`link_url`)  VALUES('5','链接名4','链接4');
INSERT INTO `tech_sys`.`bussiness_intro` (`id`,`title`,`sub_title`,`bussiness_detail`)  VALUES('1','标题0','副标题0','详细介绍0');
INSERT INTO `tech_sys`.`bussiness_intro` (`id`,`title`,`sub_title`,`bussiness_detail`)  VALUES('2','标题1','副标题1','详细介绍1');
INSERT INTO `tech_sys`.`bussiness_intro` (`id`,`title`,`sub_title`,`bussiness_detail`)  VALUES('3','标题2','副标题2','详细介绍2');
INSERT INTO `tech_sys`.`bussiness_intro` (`id`,`title`,`sub_title`,`bussiness_detail`)  VALUES('4','标题3','副标题3','详细介绍3');
INSERT INTO `tech_sys`.`bussiness_intro` (`id`,`title`,`sub_title`,`bussiness_detail`)  VALUES('5','标题4','副标题4','详细介绍4');